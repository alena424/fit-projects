﻿using System.Windows;

namespace WPFWeather
{
    public partial class WPFWeatherApp : Application
    {
    }
}