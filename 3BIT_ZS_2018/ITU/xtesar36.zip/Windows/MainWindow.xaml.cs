﻿using System.Windows;
using WPFWeather.Services;
using WPFWeather.ViewModels;
using System.Windows.Controls;
namespace WPFWeather.Windows
{
   
    public partial class MainWindow : Window
    {
        private WeatherViewModel viewmodel = new WeatherViewModel(new WeatherDiskService());

        public MainWindow()
        {
            InitializeComponent();
            DataContext = viewmodel;
        }

    }
}